package com.gizwits.opensource.appkit;

import android.app.Application;
import android.support.v4.widget.SwipeRefreshLayout;

public class GosApplication extends Application {

	public static int flag = 0;





}
