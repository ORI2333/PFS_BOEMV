package com.hisilicion.histreaming;

public class GizDeviceScheduler {
}
