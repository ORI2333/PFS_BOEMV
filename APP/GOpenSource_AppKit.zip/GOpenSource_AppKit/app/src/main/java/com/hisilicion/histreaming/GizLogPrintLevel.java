package com.hisilicion.histreaming;

public class GizLogPrintLevel {
}
