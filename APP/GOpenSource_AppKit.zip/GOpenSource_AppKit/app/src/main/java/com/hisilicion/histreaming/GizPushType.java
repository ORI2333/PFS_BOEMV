package com.hisilicion.histreaming;

public enum GizPushType {
    GizPushBaiDu,
    GizPushJiGuang;

    private GizPushType() {
    }
}