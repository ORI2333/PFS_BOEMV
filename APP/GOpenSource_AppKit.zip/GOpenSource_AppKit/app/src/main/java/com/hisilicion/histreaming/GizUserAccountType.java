package com.hisilicion.histreaming;

public enum GizUserAccountType {
    GizUserNormal,
    GizUserPhone,
    GizUserEmail,
    GizUserOther;

    private GizUserAccountType() {
    }
}
