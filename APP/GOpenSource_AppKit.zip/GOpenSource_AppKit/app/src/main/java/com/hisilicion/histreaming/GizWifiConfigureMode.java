package com.hisilicion.histreaming;

public enum GizWifiConfigureMode {
    GizWifiSoftAP,
    GizWifiAirLink;

    private GizWifiConfigureMode() {
    }
}
