package com.hisilicion.histreaming;

public enum GizWifiGAgentType {
    GizGAgentMXCHIP,
    GizGAgentHF,
    GizGAgentRTK,
    GizGAgentWM,
    GizGAgentESP,
    GizGAgentQCA,
    GizGAgentTI,
    GizGAgentFSK,
    GizGAgentMXCHIP3,
    GizGAgentBL,
    GizGAgentAtmelEE,
    GizGAgentOther;

    private GizWifiGAgentType() {
    }
}
