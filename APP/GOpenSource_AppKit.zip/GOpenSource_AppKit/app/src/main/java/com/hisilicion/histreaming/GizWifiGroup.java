package com.hisilicion.histreaming;

public class GizWifiGroup {
}
